import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def calculate_position_size(balance: float, risk_per_trade: float, entry_price: float, stop_loss_price: float) -> float:
    try:
        if balance < 10:
            raise ValueError("Balance must be at least $10.")
        if risk_per_trade <= 0 or risk_per_trade > 100:
            raise ValueError("Risk per trade must be between 0 and 100.")
        if entry_price <= 0 or stop_loss_price <= 0:
            raise ValueError("Entry price and stop loss price must be greater than zero.")
        
        risk_amount = balance * (risk_per_trade / 100)
        position_size = risk_amount / abs(entry_price - stop_loss_price)
        
        logger.info(f"Calculated position size: {position_size}")
        return position_size
    except Exception as e:
        logger.error(f"Error calculating position size: {e}")
        raise

def calculate_risk_to_reward_ratio(entry_price: float, stop_loss_price: float, target_price: float) -> float:
    try:
        if entry_price <= 0 or stop_loss_price <= 0 or target_price <= 0:
            raise ValueError("Entry price, stop loss price, and target price must be greater than zero.")
        
        potential_loss = abs(entry_price - stop_loss_price)
        potential_profit = abs(target_price - entry_price)
        
        risk_to_reward_ratio = potential_profit / potential_loss
        
        logger.info(f"Calculated risk-to-reward ratio: {risk_to_reward_ratio}")
        return risk_to_reward_ratio
    except Exception as e:
        logger.error(f"Error calculating risk-to-reward ratio: {e}")
        raise

# Example usage
if __name__ == "__main__":
    balance = 10.0
    risk_per_trade = 1.0
    entry_price = 50.0
    stop_loss_price = 48.0
    target_price = 55.0
    
    position_size = calculate_position_size(balance, risk_per_trade, entry_price, stop_loss_price)
    print(f"Position size: {position_size}")
    
    risk_to_reward_ratio = calculate_risk_to_reward_ratio(entry_price, stop_loss_price, target_price)
    print(f"Risk-to-reward ratio: {risk_to_reward_ratio}")
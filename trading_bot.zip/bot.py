import sys
import os
import json
import time
import logging
import numpy as np
import MetaTrader5 as mt5
from pathlib import Path
from typing import Dict, Tuple
from xgboost import XGBClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from strategies.moving_average_crossover import moving_average_crossover
from utils.data_fetcher import fetch_historical_data, fetch_live_data
from utils.logger import logger

# Configure paths
BASE_DIR = Path(__file__).parent.resolve()
sys.path.append(str(BASE_DIR.parent))

# Initialize MT5 connection
def initialize_mt5() -> bool:
    """Initialize connection to MetaTrader 5 terminal."""
    if not mt5.initialize():
        logger.error(f"MT5 initialization failed: {mt5.last_error()}")
        return False
    logger.info(f"Connected to MT5 Terminal {mt5.version()}")
    return True

# Load and validate configuration
def load_config() -> Dict:
    """Load and validate configuration file."""
    config_path = BASE_DIR / "config" / "config.json"
    try:
        with open(config_path) as f:
            config = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError) as e:
        logger.error(f"Config error: {str(e)}")
        sys.exit(1)

    # Schema validation
    required_keys = {
        'initial_balance': (float, 1000.0),
        'symbols': (list, ['EURUSD']),
        'risk_per_trade_percentage': (float, 1.0),
        'trade_frequency': (int, 300),
        'max_open_trades': (int, 5)
    }
    
    for key, (key_type, default) in required_keys.items():
        if key not in config:
            logger.warning(f"Missing {key}, using default: {default}")
            config[key] = default
        elif not isinstance(config[key], key_type):
            logger.error(f"Invalid type for {key}, expected {key_type.__name__}")
            sys.exit(1)
            
    return config

# Enhanced position sizing with volatility adjustment
def calculate_position_size(balance: float, risk_percent: float, 
                           current_price: float, atr: float) -> float:
    """Calculate position size with volatility-adjusted risk management."""
    risk_amount = balance * (risk_percent / 100)
    position_size = risk_amount / (atr * 1.5)  # 1.5x ATR for stop loss
    return max(min(position_size, balance * 0.1), 0.01)  # 10% max exposure

# Technical indicators with validation
def add_technical_indicators(df):
    """Add technical indicators with proper validation."""
    try:
        import talib
    except ImportError:
        logger.critical("TA-Lib required: pip install TA-Lib")
        sys.exit(1)
        
    required_columns = {'open', 'high', 'low', 'close'}
    if not required_columns.issubset(df.columns):
        logger.error("Missing price columns in dataframe")
        return df

    try:
        df['RSI'] = talib.RSI(df['close'], timeperiod=14)
        df['macd'], df['macd_signal'], _ = talib.MACD(df['close'])
        df['ATR'] = talib.ATR(df['high'], df['low'], df['close'], timeperiod=14)
        df['EMA_20'] = talib.EMA(df['close'], timeperiod=20)
        return df.dropna()
    except Exception as e:
        logger.error(f"Indicator calculation failed: {str(e)}")
        return df

# ML Model Training with data leakage prevention
class MLModel:
    """Machine learning model manager with periodic retraining"""
    def __init__(self):
        self.model = None
        self.scaler = None
        self.last_trained = None
        
    def train(self, df, retrain_interval=3600):
        """Train model with periodic refreshes"""
        if not self.requires_retraining(retrain_interval):
            return
            
        features = ['EMA_20', 'RSI', 'macd', 'ATR']
        X = df[features]
        y = df['signal']
        
        # Prevent data leakage
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, shuffle=False
        )
        
        self.scaler = StandardScaler()
        X_train_scaled = self.scaler.fit_transform(X_train)
        X_test_scaled = self.scaler.transform(X_test)
        
        self.model = XGBClassifier(
            n_estimators=100,
            max_depth=3,
            learning_rate=0.1,
            subsample=0.8
        )
        self.model.fit(X_train_scaled, y_train)
        self.last_trained = time.time()
        
        # Validate model performance
        test_score = self.model.score(X_test_scaled, y_test)
        logger.info(f"Model retrained. Test accuracy: {test_score:.2%}")

    def requires_retraining(self, interval):
        """Check if model needs retraining"""
        if self.model is None:
            return True
        return (time.time() - self.last_trained) > interval

# Trading execution module
class TradeExecutor:
    """Handle trade execution and risk management"""
    def __init__(self, config):
        self.config = config
        self.open_trades = []
        self.balance = config['initial_balance']
        
    def execute_trade(self, symbol: str, signal: int, price: float, size: float):
        """Execute trade through MT5 platform"""
        if len(self.open_trades) >= self.config['max_open_trades']:
            logger.warning("Max open trades reached")
            return
            
        trade_type = mt5.ORDER_TYPE_BUY if signal == 1 else mt5.ORDER_TYPE_SELL
        request = {
            "action": mt5.TRADE_ACTION_DEAL,
            "symbol": symbol,
            "volume": round(size, 2),
            "type": trade_type,
            "price": price,
            "deviation": 20,
            "magic": 1001,
            "comment": "AI Trade",
            "type_time": mt5.ORDER_TIME_GTC,
            "type_filling": mt5.ORDER_FILLING_IOC,
        }
        
        try:
            result = mt5.order_send(request)
            if result.retcode != mt5.TRADE_RETCODE_DONE:
                logger.error(f"Trade failed: {result.comment}")
            else:
                self.open_trades.append(result.order)
                logger.info(f"Trade executed: {result}")
        except Exception as e:
            logger.error(f"Trade execution error: {str(e)}")

def main():
    """Main trading loop"""
    config = load_config()
    
    if not initialize_mt5():
        sys.exit(1)
        
    ml_model = MLModel()
    executor = TradeExecutor(config)
    
    logger.info("Starting trading bot...")
    try:
        while True:
            for symbol in config['symbols']:
                try:
                    # Data collection
                    hist_data = fetch_historical_data(symbol)
                    live_data = fetch_live_data(symbol)
                    
                    if hist_data.empty or live_data is None:
                        continue
                        
                    # Feature engineering
                    hist_data = moving_average_crossover(hist_data)
                    hist_data = add_technical_indicators(hist_data)
                    
                    # Model training
                    ml_model.train(hist_data)
                    
                    # Generate signal
                    current_features = ml_model.scaler.transform(
                        hist_data[['EMA_20', 'RSI', 'macd', 'ATR']].iloc[-1:])
                    signal = ml_model.model.predict(current_features)[0]
                    
                    # Execute trade
                    if signal != 0:
                        atr = hist_data['ATR'].iloc[-1]
                        price = live_data['last']
                        size = calculate_position_size(
                            executor.balance,
                            config['risk_per_trade_percentage'],
                            price,
                            atr
                        )
                        executor.execute_trade(symbol, signal, price, size)
                        
                except Exception as e:
                    logger.error(f"Symbol {symbol} error: {str(e)}")
                    continue
                    
            time.sleep(config['trade_frequency'])
            
    except KeyboardInterrupt:
        logger.info("Shutting down trading bot...")
    finally:
        mt5.shutdown()

if __name__ == "__main__":
    main()
    
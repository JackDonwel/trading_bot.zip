# strategies/moving_average_crossover.py
import pandas as pd
import numpy as np
import talib
from typing import Tuple, Optional
from pathlib import Path
from utils.logger import logger

# Type aliases
DF = pd.DataFrame

def validate_dataframe(df: DF, required_cols: list) -> None:
    """Validate dataframe structure and content."""
    if not isinstance(df, pd.DataFrame):
        raise ValueError("Input must be a pandas DataFrame")
    
    missing = [col for col in required_cols if col not in df.columns]
    if missing:
        raise ValueError(f"Missing required columns: {missing}")

def calculate_moving_averages(
    df: DF, 
    short_window: int = 10, 
    long_window: int = 50
) -> DF:
    """
    Calculate moving averages using TA-Lib for better performance.
    
    Args:
        df: DataFrame containing price data
        short_window: Short MA window (default: 10)
        long_window: Long MA window (default: 50)
        
    Returns:
        DataFrame with MA columns added
    """
    required_cols = ['close']
    validate_dataframe(df, required_cols)
    
    try:
        df['short_ma'] = talib.SMA(df['close'], timeperiod=short_window)
        df['long_ma'] = talib.SMA(df['close'], timeperiod=long_window)
        df['signal'] = np.where(df['short_ma'] > df['long_ma'], 1, -1)
        return df.dropna()
    except Exception as e:
        logger.error(f"MA calculation failed: {str(e)}")
        raise

def calculate_technical_indicators(df: DF) -> DF:
    """
    Calculate full set of technical indicators with validation.
    
    Args:
        df: DataFrame containing OHLC price data
        
    Returns:
        DataFrame with technical indicators added
    """
    required_cols = ['open', 'high', 'low', 'close']
    validate_dataframe(df, required_cols)
    
    try:
        # RSI
        df['rsi'] = talib.RSI(df['close'], timeperiod=14)
        
        # Bollinger Bands
        df['bb_upper'], df['bb_middle'], df['bb_lower'] = talib.BBANDS(
            df['close'], timeperiod=20
        )
        
        # MACD
        df['macd'], df['macd_signal'], df['macd_hist'] = talib.MACD(
            df['close'], fastperiod=12, slowperiod=26, signalperiod=9
        )
        
        # Stochastic
        df['slowk'], df['slowd'] = talib.STOCH(
            df['high'], df['low'], df['close'],
            fastk_period=14, slowk_period=3, slowd_period=3
        )
        
        return df.dropna()
    except talib.TALIBError as e:
        logger.error(f"TA-Lib error: {str(e)}")
        raise
    except Exception as e:
        logger.error(f"Indicator calculation failed: {str(e)}")
        raise

def calculate_position_size(
    df: DF,
    risk_percent: float = 1.0,
    atr_multiplier: float = 1.5
) -> DF:
    """
    Calculate position size based on volatility-adjusted risk management.
    
    Args:
        df: DataFrame containing price and indicator data
        risk_percent: Percentage of capital to risk per trade
        atr_multiplier: Multiplier for ATR-based stop loss
        
    Returns:
        DataFrame with position size column added
    """
    required_cols = ['close', 'atr', 'signal']
    validate_dataframe(df, required_cols)
    
    try:
        df['atr'] = talib.ATR(
            df['high'], df['low'], df['close'], timeperiod=14
        )
        
        df['position_size'] = (
            (risk_percent / 100) / (df['atr'] * atr_multiplier)
        ).clip(upper=0.1)  # Max 10% of capital per trade
        
        return df
    except Exception as e:
        logger.error(f"Position sizing failed: {str(e)}")
        raise

def backtest_strategy(
    df: DF,
    commission: float = 0.0002,
    slippage: float = 0.0001
) -> Tuple[DF, pd.Series]:
    """
    Backtest strategy with realistic market assumptions.
    
    Args:
        df: DataFrame with strategy signals
        commission: Trade commission percentage
        slippage: Price slippage percentage
        
    Returns:
        Tuple of (DataFrame with results, performance metrics)
    """
    required_cols = ['close', 'signal']
    validate_dataframe(df, required_cols)
    
    try:
        # Calculate returns
        df['returns'] = df['close'].pct_change()
        
        # Apply trading costs
        df['strategy_returns'] = (
            df['signal'].shift(1) * df['returns'] - 
            (commission + slippage) * np.abs(df['signal'].diff())
        )
        
        # Calculate performance metrics
        df['cumulative_returns'] = (1 + df['strategy_returns']).cumprod()
        df['drawdown'] = df['cumulative_returns'] / df['cumulative_returns'].cummax() - 1
        
        # Calculate key metrics
        metrics = pd.Series({
            'total_return': df['cumulative_returns'].iloc[-1] - 1,
            'max_drawdown': df['drawdown'].min(),
            'sharpe_ratio': np.sqrt(252) * df['strategy_returns'].mean() / df['strategy_returns'].std(),
            'win_rate': (df['strategy_returns'] > 0).mean()
        })
        
        return df, metrics
    except Exception as e:
        logger.error(f"Backtesting failed: {str(e)}")
        raise

def execute_strategy_pipeline(
    df: DF,
    config: dict
) -> Tuple[DF, pd.Series]:
    """
    Execute complete strategy pipeline.
    
    Args:
        df: Raw price data DataFrame
        config: Strategy configuration dictionary
        
    Returns:
        Tuple of (processed DataFrame, performance metrics)
    """
    logger.info("Starting strategy pipeline")
    
    try:
        # Calculate indicators
        df = calculate_moving_averages(
            df,
            config.get('short_window', 10),
            config.get('long_window', 50)
        )
        
        df = calculate_technical_indicators(df)
        df = calculate_position_size(
            df,
            config.get('risk_percent', 1.0),
            config.get('atr_multiplier', 1.5)
        )
        
        # Backtest strategy
        results, metrics = backtest_strategy(
            df,
            config.get('commission', 0.0002),
            config.get('slippage', 0.0001)
        )
        
        logger.info("Strategy pipeline completed successfully")
        return results, metrics
        
    except Exception as e:
        logger.error(f"Strategy pipeline failed: {str(e)}")
        raise

def save_results(df: DF, filename: str = "strategy_results") -> None:
    """Save results to parquet file with validation."""
    try:
        output_dir = Path("results")
        output_dir.mkdir(exist_ok=True)
        
        path = output_dir / f"{filename}.parquet"
        df.to_parquet(path)
        logger.info(f"Results saved to {path}")
    except Exception as e:
        logger.error(f"Failed to save results: {str(e)}")
        raise
